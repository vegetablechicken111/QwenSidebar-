(() => {
  'use strict';

  const host = location.hostname;
  if (!host.endsWith('qianwen.com') && !host.endsWith('qwen.ai')) {
    return;
  }

  const CN_PREFIXES = ['https://www.qianwen.com/chat/', 'https://qianwen.com/chat/'];
  const INTL_PREFIX = 'https://chat.qwen.ai/c/';
  const CN_ID = /^[0-9a-f]{16,}/i;
  const INTL_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;

  let lastReported = '';

  function report() {
    try {
      const url = location.href;
      let key = '';
      if (CN_PREFIXES.some(prefix => url.startsWith(prefix))) {
        key = 'lastChat.cn';
        if (!CN_ID.test(url.split('/chat/')[1] || '')) {
          return;
        }
      } else if (url.startsWith(INTL_PREFIX)) {
        key = 'lastChat.intl';
        if (!INTL_ID.test(url.split('/c/')[1] || '')) {
          return;
        }
      } else {
        return;
      }
      if (url !== lastReported) {
        lastReported = url;
        chrome.storage.local.set({ [key]: url });
      }
    } catch (err) {
      /* storage can be unavailable during extension reload */
    }
  }

  window.addEventListener('popstate', report);
  window.addEventListener('hashchange', report);
  window.addEventListener('pagehide', report);
  setInterval(report, 1000);
  report();
})();
