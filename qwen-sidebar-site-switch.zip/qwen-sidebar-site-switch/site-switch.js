(() => {
  'use strict';

  const SITES = {
    cn: 'https://www.qianwen.com/',
    intl: 'https://chat.qwen.ai/'
  };
  const CHAT_PATTERNS = {
    cn: /^https:\/\/(?:www\.)?qianwen\.com\/chat\/[0-9a-f]{16,}/i,
    intl: /^https:\/\/chat\.qwen\.ai\/c\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i
  };
  const CACHE_KEY = 'qwenSidebar.siteMode';
  const KEEP_CACHE_KEY = 'qwenSidebar.keepSession';
  const SYNC_KEY = 'siteMode';
  const KEEP_KEY = 'keepSession';
  const DEFAULT_MODE = 'cn';

  function normalize(value) {
    return value === 'intl' ? 'intl' : 'cn';
  }

  function readCache() {
    try {
      return normalize(localStorage.getItem(CACHE_KEY));
    } catch (err) {
      return DEFAULT_MODE;
    }
  }

  function writeCache(mode) {
    try {
      localStorage.setItem(CACHE_KEY, mode);
    } catch (err) {
      /* sync storage still works */
    }
  }

  function readKeepCache() {
    try {
      const value = localStorage.getItem(KEEP_CACHE_KEY);
      return value === null ? true : value !== '0';
    } catch (err) {
      return true;
    }
  }

  function writeKeepCache(enabled) {
    try {
      localStorage.setItem(KEEP_CACHE_KEY, enabled ? '1' : '0');
    } catch (err) {
      /* storage.local remains the source of truth */
    }
  }

  function keyFor(mode) {
    return 'lastChat.' + mode;
  }

  let currentMode = readCache();
  let restored = {};
  let ready = false;
  let keepSession = readKeepCache();

  function targetUrl(mode) {
    if (!keepSession) {
      return SITES[mode];
    }
    const saved = restored[keyFor(mode)];
    if (typeof saved === 'string' && CHAT_PATTERNS[mode].test(saved)) {
      return saved;
    }
    return SITES[mode];
  }

  window.__QWEN_SITE_SRC__ = 'about:blank';

  function renderKeepButton() {
    const button = document.getElementById('site-switch-keep');
    if (!button) {
      return;
    }
    button.setAttribute('aria-pressed', keepSession ? 'true' : 'false');
    button.textContent = keepSession ? '驻留 · 开' : '驻留 · 关';
    button.title = keepSession
      ? '页面驻留已开启：下次打开侧边栏会回到上次会话'
      : '页面驻留已关闭：下次打开侧边栏从站点首页开始';
  }

  function updateIframe(mode) {
    const url = targetUrl(mode);
    window.__QWEN_SITE_SRC__ = url;
    const frame = document.getElementById('iframe-qianwen');
    if (frame && frame.getAttribute('src') !== url) {
      frame.setAttribute('src', url);
    }
  }

  function applyMode(mode, persist) {
    const next = normalize(mode);
    currentMode = next;
    writeCache(next);
    const select = document.getElementById('site-switch-select');
    if (select && select.value !== next) {
      select.value = next;
    }
    updateIframe(next);
    if (persist && chrome.storage && chrome.storage.sync) {
      try {
        chrome.storage.sync.set({ [SYNC_KEY]: next });
      } catch (err) {
        /* sync unavailable for unpacked extensions */
      }
    }
  }

  const select = document.getElementById('site-switch-select');
  if (select) {
    select.value = currentMode;
    select.addEventListener('change', () => applyMode(select.value, true));
  }

  const newButton = document.getElementById('site-switch-new');
  if (newButton) {
    newButton.addEventListener('click', () => {
      const key = keyFor(currentMode);
      delete restored[key];
      try {
        chrome.storage.local.remove(key);
      } catch (err) {
        /* in-memory cache is cleared regardless */
      }
      window.__QWEN_SITE_SRC__ = SITES[currentMode];
      const frame = document.getElementById('iframe-qianwen');
      if (frame) {
        frame.setAttribute('src', SITES[currentMode]);
      }
    });
  }

  const keepButton = document.getElementById('site-switch-keep');
  if (keepButton) {
    keepButton.addEventListener('click', () => {
      keepSession = !keepSession;
      writeKeepCache(keepSession);
      renderKeepButton();
      try {
        chrome.storage.local.set({ [KEEP_KEY]: keepSession });
      } catch (err) {
        /* local cache still applies */
      }
      /* Deliberately do not reload the iframe: switching the toggle must not
         interrupt the conversation currently on screen. It takes effect the
         next time the side panel is opened or the site is switched. */
    });
  }
  renderKeepButton();

  const fallback = setTimeout(() => {
    if (!ready) {
      ready = true;
      applyMode(currentMode, false);
    }
  }, 500);

  try {
    chrome.storage.local.get(['lastChat.cn', 'lastChat.intl', KEEP_KEY], data => {
      restored = data || {};
      if (typeof restored[KEEP_KEY] === 'boolean') {
        keepSession = restored[KEEP_KEY];
        writeKeepCache(keepSession);
        renderKeepButton();
      }
      ready = true;
      clearTimeout(fallback);
      applyMode(currentMode, false);
      try {
        chrome.storage.sync.get(SYNC_KEY, syncData => {
          const remote = syncData && syncData[SYNC_KEY];
          if (remote && normalize(remote) !== currentMode) {
            applyMode(remote, false);
          }
        });
      } catch (err) {
        /* keep the locally cached mode */
      }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local') {
        for (const key of Object.keys(changes)) {
          if (key === KEEP_KEY) {
            const value = changes[key].newValue;
            keepSession = typeof value === 'boolean' ? value : true;
            writeKeepCache(keepSession);
            renderKeepButton();
          } else if (key.indexOf('lastChat.') === 0) {
            const value = changes[key].newValue;
            if (typeof value === 'string') {
              restored[key] = value;
            } else {
              delete restored[key];
            }
          }
        }
        return;
      }
      if (area === 'sync' && changes[SYNC_KEY]) {
        const next = normalize(changes[SYNC_KEY].newValue);
        if (next !== currentMode) {
          applyMode(next, false);
        }
      }
    });
  } catch (err) {
    if (!ready) {
      ready = true;
      clearTimeout(fallback);
      applyMode(currentMode, false);
    }
  }
})();
